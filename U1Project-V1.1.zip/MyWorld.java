    import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
    
    /**
     * Write a description of class MyWorld here.
     * 
     * @author (your name) 
     * @version (a version number or a date)
     */
    public class MyWorld extends World
    {
        Start button = new Start();
        lvl1Hut StoneHut1 = new lvl1Hut();
        lvl1Hut StoneHut2 = new lvl1Hut();
        minigameStar StoneStar1 = new minigameStar();
        test_minigame test_button = new test_minigame();
        int tasksComplete;
        level2Button Button2 = new level2Button();
        /**
         * Constructor for objects of class MyWorld.
         * 
         */
        public MyWorld()
        {    
            // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
            super(1200, 900, 1); 
            prepareStart();
            act();
            
        }
        
        public void act() {
           level1();
           stoneMinigame1();
           level2();
            
           
        }
        
        public void prepareStart() {
            
            addObject(button, 600,800);
            
            
            
        }
        
        public void level1() {
            if (Greenfoot.mouseClicked(button)) {
               removeObject(button);
               setBackground("lvl1.jpg");
               addObject(StoneHut1, 900, 300);
               addObject(StoneHut2, 500, 600);
               addObject(StoneStar1, 900, 250);
               stoneMinigame1();
              
            }
            
        }
        
        public void stoneMinigame1() {
            if (Greenfoot.mouseClicked(StoneStar1)) {
               removeObject(StoneHut1);
               removeObject(StoneHut2);
               removeObject(StoneStar1);
               setBackground("grassBackground.jpg");
               addObject(test_button, 600, 400);
               
            }
            if (Greenfoot.mouseClicked(test_button)) {
               tasksComplete += 1;
               removeObject(test_button);
               setBackground("lvl1.jpg");
               addObject(StoneHut1, 900, 300);
               addObject(StoneHut2, 500, 600);
               addObject(StoneStar1, 900, 250);
               System.out.println("Task complete: 1/1");
               removeObject(StoneStar1);
               
            }
        }
        
        
        public void level2() {
            if (tasksComplete == 1) {
                addObject(Button2, 600, 800);
                tasksComplete = 0;
            }
            if (Greenfoot.mouseClicked(Button2)) {
                setBackground("lvl2.jpg");
                removeObject(Button2);
                removeObject(StoneHut1);
                removeObject(StoneHut2);
            }
            
        }
}
